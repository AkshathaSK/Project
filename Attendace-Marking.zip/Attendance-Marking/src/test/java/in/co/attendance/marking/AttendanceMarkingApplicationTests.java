package in.co.attendance.marking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttendanceMarkingApplicationTests {

	@Test
	void contextLoads() {
	}

}
