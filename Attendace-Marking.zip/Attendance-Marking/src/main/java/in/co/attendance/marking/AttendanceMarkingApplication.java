package in.co.attendance.marking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AttendanceMarkingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AttendanceMarkingApplication.class, args);
	}
}
