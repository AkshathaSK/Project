package in.co.attendance.marking.dto;


public interface DropdownList
{
	public String getKey();

	public String getValue();
}
